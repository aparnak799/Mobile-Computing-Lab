package com.example.myapplication;

import android.widget.DatePicker;
import android.widget.TimePicker;

public class Details {
    String name, address, age, phone, gender, marital, addiction;
    DatePicker dob;
    TimePicker time;
}
