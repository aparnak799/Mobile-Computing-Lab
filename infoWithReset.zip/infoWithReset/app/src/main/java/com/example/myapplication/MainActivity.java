package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Details details = new Details();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.marital_status, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        final EditText e2 =findViewById(R.id.editText2);
        final EditText e8 =findViewById(R.id.editText8);
        final Button cb = findViewById(R.id.calButton);
        final Button reset = (Button)findViewById(R.id.resetButton);
        Button button = (Button) findViewById(R.id.submitButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context, "Details Submitted", Toast.LENGTH_LONG);
                toast.show();*/
                EditText e1 = (EditText) findViewById(R.id.editText2);
                details.name = e1.getText().toString();

                final EditText e2 = (EditText) findViewById((R.id.editText3));
                details.address = e2.getText().toString();

                EditText e3 = (EditText) findViewById((R.id.editText4));
                details.age = e3.getText().toString();

                DatePicker d = (DatePicker) findViewById((R.id.simpleDatePicker));
                details.dob = d;

                RadioGroup r = (RadioGroup) findViewById(R.id.RadioGroup);
                Integer rid = (Integer)r.getCheckedRadioButtonId();

                RadioButton r1 = (RadioButton) findViewById(rid);
                details.gender = r1.getText().toString();

                cb.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        Calendar calendar = Calendar.getInstance();
                        int year=calendar.get(Calendar.YEAR);
                        int month=calendar.get(Calendar.MONTH);
                        int day=calendar.get(Calendar.DAY_OF_MONTH);
                        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener()
                        {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth)
                            {

                            }
                        }, myear, mMonth, mDay);
                        datePickerDialog.show();
                        e8.setText("" + dayOfMonth + " - " + (monthOfYear+1) + " - " + year)
                    }
                });
                reset.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view)
                    {
                        e2.setText("");

                    }
                });
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context, details.marital, Toast.LENGTH_LONG);
                toast.show();
            }
        });
    }
}
